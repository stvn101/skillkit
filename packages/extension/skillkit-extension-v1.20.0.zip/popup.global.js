"use strict";
(() => {
  // src/constants.ts
  var RESTRICTED_PREFIXES = [
    "chrome://",
    "chrome-extension://",
    "https://chromewebstore.google.com",
    "about:"
  ];
  function isRestricted(url) {
    if (!url) return true;
    return RESTRICTED_PREFIXES.some((p) => url.startsWith(p));
  }

  // src/popup.ts
  var pageTitle = document.getElementById("page-title");
  var pageUrl = document.getElementById("page-url");
  var skillNameInput = document.getElementById(
    "skill-name"
  );
  var saveBtn = document.getElementById("save-btn");
  var statusEl = document.getElementById("status");
  var statusIcon = document.getElementById("status-icon");
  var statusText = document.getElementById("status-text");
  var resultEl = document.getElementById("result");
  var resultPath = document.getElementById("result-path");
  var currentUrl = "";
  var currentTitle = "";
  var currentTabId = 0;
  async function init() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) return;
    pageTitle.textContent = tab.title || "Unknown";
    pageUrl.textContent = tab.url || "\u2014";
    currentUrl = tab.url || "";
    currentTitle = tab.title || "";
    currentTabId = tab.id;
    if (isRestricted(currentUrl)) {
      saveBtn.setAttribute("disabled", "");
      setStatus("error", "Cannot save skills from this page");
      return;
    }
  }
  saveBtn.addEventListener("click", async () => {
    if (!currentUrl || !currentTabId) return;
    setStatus("saving", "Saving...");
    saveBtn.setAttribute("disabled", "");
    const message = {
      type: "SAVE_PAGE",
      payload: {
        url: currentUrl,
        title: currentTitle,
        name: skillNameInput.value.trim() || void 0,
        tabId: currentTabId
      }
    };
    const response = await chrome.runtime.sendMessage(message);
    saveBtn.removeAttribute("disabled");
    if (!response) {
      setStatus("error", "No response from background script");
      resultEl.style.display = "none";
      return;
    }
    if ("error" in response) {
      setStatus("error", response.error);
      resultEl.style.display = "none";
      return;
    }
    setStatus("success", `Saved "${response.name}"`);
    resultPath.textContent = `Downloads/skillkit-skills/${response.filename}`;
    resultEl.style.display = "block";
  });
  function setStatus(type, text) {
    statusEl.style.display = "flex";
    statusEl.className = `status ${type}`;
    const icons = { saving: "...", success: "\u2713", error: "\u2717" };
    statusIcon.textContent = icons[type];
    statusText.textContent = text;
  }
  init();
})();
